<!-- Global layout -->


<!-- Dynamic Tiltile  -->
<?php $__env->startSection('title', 'Page Title'); ?>

<!-- Page Content -->
<?php $__env->startSection('content'); ?>
    
    <!-- Slider DOM -->
    <?php echo $__env->make('frontend.home.section.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>