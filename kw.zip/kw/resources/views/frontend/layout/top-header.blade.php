<header class="header-top">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="email">
                    <a href="mailto:info@kanoonvala.com"><i class="fa fa-envelope"></i>info@kanoonvala.com</a>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12 text-left">
                <span style="color:white;">Follow Us :</span>&nbsp;&nbsp;
                <a href="https://www.facebook.com/Kanoonvala-1734079183334384/" target="_blank"><img src="assets/img/facebook.png" style="width: 28px;margin-left: 87px;padding-bottom: 15px;"></a>
                <a href="https://twitter.com/kanoonvala" target="_blank"><img src="assets/img/twitter.png" style="width: 27px;margin-left: 127px;padding-bottom: 16px;"></a>
                <a href="http://kanoonvala.com/" target="_blank"><img src="assets/img/Linked.png" style="width: 28px;margin-left: 166px; margin-bottom: 16px;"></a>
            </div>
            
            <div class="col-md-3 col-sm-6 col-xs-12 text-right">
                <div class="search-box">
                  <span>
                      
                  </span>
              </div>
              
          </div>
          
          <div class="col-md-3 col-sm-6 col-xs-12 text-right">
            <div class="search-box">
              <span>
                  <a class="nav-link" href="http://kanoonvala.com/"><b style="border:1px solid white;  padding-right:2px;padding-left:2px;">CA SERVICES</b></a>&nbsp;&nbsp;&nbsp;
                  <a href="whatsapp://send" data-text="Take a look at this awesome website:" data-href="" class="wa_btn wa_btn_s" ></a>
                  <a class="nav-link" href="tel:+91 (935)443-8542" style="padding-left:2px;">Call : +91 9354438542</a>
              </span>
          </div>
          
      </div>
  </div>
</div>
</header>
